$CurrentYear = [DateTime]::Today.Year.ToString()

function validPath($path)
{
	return !(test-Path -Path $path -PathType leaf)
}

function DLLListing{
	[cmdletbinding()]
	Param(
		[Parameter(Mandatory=$true)]
			[string]$ServerName,
		[Parameter(Mandatory=$true)]
			[string]$RemotePath,
		[Parameter(Mandatory=$False)]
			[string]$Year=$CurrentYear,
		[Parameter(Mandatory=$false)]
			[string]$Filter="*.dll"
	)

	Process
	{
		$remotePath = "\\$($ServerName)\$($RemotePath)"
		$FirstOfYear = New-Object DateTime($Year, 1, 1)
		
		$x = Get-ChildItem $RemotePath -Filter $Filter -Recurse | 
			where {$_.LastWriteTime -gt $FirstOfYear} | 
			Select Name, LastWriteTime, DirectoryName |
			Export-CSV "$($ServerName).csv" -NoTypeInformation
		
	}
}

$APPSServers = @("PHLYWBP046",
				"PHLYWBP061"
)

$APPSPath = "d$\inetpub\wwwroot\apps"

ForEach ($Server in $APPSServers) {
	DLLListing -ServerName $Server -RemotePath $APPSPath -Filter "*.*"
}