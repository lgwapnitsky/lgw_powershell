$CurrentYear = [DateTime]::Today.Year.ToString()

function validPath($path)
{
	return !(test-Path -Path $path -PathType leaf)
}

function DLLListing{
	[cmdletbinding()]
	Param(
		[Parameter(Mandatory=$true)]
			[string]$ServerName,
		[Parameter(Mandatory=$true)]
			[string]$RemotePath,
		[Parameter(Mandatory=$False)]
			[string]$Year=$CurrentYear,
		[Parameter(Mandatory=$false)]
			[string]$Filter="*.dll"
	)

	Process
	{
		$remotePath = "\\$($ServerName)\$($RemotePath)"
		$FirstOfYear = New-Object DateTime($Year, 1, 1)
		
		$x = Get-ChildItem $RemotePath -Filter $Filter | 
			where {$_.LastWriteTime -gt $FirstOfYear} | 
			Select Name, LastWriteTime |
			Export-CSV "$($ServerName).csv" -NoTypeInformation
		
	}
}

$AQSServers = @("PHLYWBP010",
				"PHLYWBP011",
				"PHLYWBP012",
				"PHLYWBP013",
				"PHLYWBP013A",
				"PHLYWBP014",
				"PHLYWBP017",
				"PHLYWBP027",
				"PHLYWBP030",
				"PHLYWBP031",
				"PHLYWBP032",
				"PHLYWBP033",
				"PHLYWBP034",
				"PHLYWBP035",
				"PHLYWBP035A",
				"PHLYWBP036",
				"PHLYWBP037",
				"PHLYWBP038",
				"PHLYWBP039"
)

$AQSPath = "d$\program files\AQS\Advantage\Website\bin"

ForEach ($Server in $AQSServers) {
	DLLListing -ServerName $Server -RemotePath $AQSPath
}